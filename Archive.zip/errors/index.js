const { errorStatus500 } = require("./500");
const { bodyRequirer } = require("./bodyRequirer");

module.exports = { errorStatus500, bodyRequirer };
