const coupons = [
  {
    id: 1,
    code: "AEMA_MEM",
    discount_for: 33,
    title: "Only for AEMA employee!",
  },
  { id: 3, code: "A9EM7A7S", discount_for: 50, title: "Super Discount!" },
  { id: 2, code: "78TYLK09", discount_for: 28, title: "Special for you!" },
  {
    id: 2,
    code: "XCDOLMIY",
    discount_for: 15,
    title: "Only for Community Members!",
  },
];

module.exports = coupons;
