const flower_discount = [
  {
    id: 1,
    title: "Super Sale",
    discoount_up_to: 75,
    poster_image_url:
      "https://firebasestorage.googleapis.com/v0/b/aema-image-upload.appspot.com/o/greenshop%2Fimages%2FIMPATIENS.png?alt=media&token=0aa1f591-8250-4c8f-8b9b-7f88664d85a4",
  },
  {
    id: 2,
    title: "Do not miss the opportunity!",
    discoount_up_to: 52,
    poster_image_url:
      "https://firebasestorage.googleapis.com/v0/b/aema-image-upload.appspot.com/o/greenshop%2Fimages%2Fbromeliads.png?alt=media&token=67d52029-069b-451d-8dbc-342f783b46f8",
  },
  {
    id: 3,
    title: "The biggest discount!",
    discoount_up_to: 78,
    poster_image_url:
      "https://cdn.pixabay.com/photo/2019/02/16/11/34/potted-plant-4000135_960_720.png",
  },
  {
    id: 4,
    title: "Stay updated!",
    discoount_up_to: 23,
    poster_image_url:
      "https://firebasestorage.googleapis.com/v0/b/aema-image-upload.appspot.com/o/greenshop%2Fimages%2Fafrican_violet.png?alt=media&token=821c06d0-4b3c-4931-9717-40efdba2f458",
  },
  {
    id: 5,
    title: "One in a centure!",
    discoount_up_to: 99,
    poster_image_url:
      "https://firebasestorage.googleapis.com/v0/b/aema-image-upload.appspot.com/o/greenshop%2Fimages%2Fbromeliads.png?alt=media&token=67d52029-069b-451d-8dbc-342f783b46f8",
  },
];

module.exports = flower_discount;
